clear all; close all;
format long
Eb = 3.2e10; 
Ea = 2.0e11;
L =?;
h =?;
Ap = h^2;
I = h^4/12;
Ab = ??;
Lb = ??;

% Kmatrix
Kf = Eb*I/L^3*[12	6*L	-12	6*L;
6*L 4*L^2 -6*L 2*L^2 ;-12 -6*L	12 -6*L;
6*L 2*L^2 -6*L 4*L^2];
%TO BE COMPLETED

%Part1
F=[??];
%Reduced system to solve in the global/local axis
??
??
U1=K1\F1;
%precise the units

%Check the reaction forces

% ... 

%Part2
%
%Axial part of the beam
Ka=Eb*Ap/L*[1 -1; -1 1];

% Axial-Bending rigidity, specify DOFs

% 2D bar 




%Rotation


%Assembly per DOF global coordinate




%BCs


%F
F=??
U = K\F  %solution

%check Reactions

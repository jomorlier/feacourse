function AxialBarFEM
%Comment please with the right word
%Copy paste part of the code in the ?? at the right place
B*u
[-1/h 1/h]
d = inv(Kred)*fred
(A*E/h)*[[1 -1];[-1 1]]
E*eps



%
%
%
 A = 1.0;
 L = 1.0;
 E = 1.0;
 a = 1.0;
 R = 1.0;
%
%
%

 e = 3;
 h = L/e;
 n = e+1;

 for i=1:n
  node(i) = (i-1)*h;
 end

 for i=1:e
  elem(i,:) = [i i+1];
 end

%
%
%

 K = zeros(n);
 f = zeros(n,1);
 for i=1:e
  node1 = elem(i,1);
  node2 = elem(i,2);
  Ke = elementStiffness(A, E, h);
  fe = elementLoad(node(node1),node(node2), a, h);
  K(node1:node2,node1:node2) = K(node1:node2,node1:node2) + Ke;
  f(node1:node2) = f(node1:node2) + fe;
 end


%
%BCs &Loads
%
 f(n) = f(n) + 1.0;


 Kred = K(2:n,2:n);
 fred = f(2:n);


%
%
%
 
 d = ??;
 
 dsol = [0 d'];
 
 fsol = K*dsol';
 sum(fsol)
 


%
%
%
 figure;
 p0 = plotDisp(E, A, L, R, a);
 p1 = plot(node, dsol, 'ro--', 'LineWidth', 3); hold on;
 legend([p0 p1],'Exact','FEM');
 
 for i=1:e
  node1 = elem(i,1);
  node2 = elem(i,2);
  u1 = dsol(node1);
  u2 = dsol(node2);
  [eps(i), sig(i)] = elementStrainStress(u1, u2, E, h);
 end

 figure;
 p0 = plotStress(E, A, L, R, a);
 for i=1:e
  node1 = node(elem(i,1));
  node2 = node(elem(i,2));
  p1 = plot([node1 node2], [sig(i) sig(i)], 'r-','LineWidth',3); hold on;
 end
 legend([p0 p1],'Exact','FEM');


  function [p] = plotDisp(E, A, L, R, a)

 dx = 0.01;
 nseg = L/dx;
 for i=1:nseg+1
  x(i) = (i-1)*dx;
  u(i) = (1/6*A*E)*(-a*x(i)^3 + (6*R + 3*a*L^2)*x(i));
 end
 p = plot(x, u, 'LineWidth', 3); hold on;
 xlabel('x', 'FontName', 'palatino', 'FontSize', 18);
 ylabel('u(x)', 'FontName', 'palatino', 'FontSize', 18);
 set(gca, 'LineWidth', 3, 'FontName', 'palatino', 'FontSize', 18);

  function [p] = plotStress(E, A, L, R, a)

 dx = 0.01;
 nseg = L/dx;
 for i=1:nseg+1
  x(i) = (i-1)*dx;
  sig(i) = (1/2*A*E)*(-a*x(i)^2 + (2*R + a*L^2));
 end
 p = plot(x, sig, 'LineWidth', 3); hold on;
 xlabel('x', 'FontName', 'palatino', 'FontSize', 18);
 ylabel('\sigma(x)', 'FontName', 'palatino', 'FontSize', 18);
 set(gca, 'LineWidth', 3, 'FontName', 'palatino', 'FontSize', 18);

  function [Ke] = elementStiffness(A, E, h)

 Ke = ??;

  function [fe] = elementLoad(node1, node2, a, h)

 x1 = node1;
 x2 = node2;

 fe1 = a*x2/(2*h)*(x2^2-x1^2) - a/(3*h)*(x2^3-x1^3);
 fe2 = -a*x1/(2*h)*(x2^2-x1^2) + a/(3*h)*(x2^3-x1^3);
 fe = [fe1;fe2];

  function [eps, sig] = elementStrainStress(u1, u2, E, h)

 B = ??;
 u = [u1; u2];
 eps =??
 sig = ??;
